import{a as i}from"https://app.framerstatic.com/chunk-4FU7DO35.mjs";import{c as n}from"https://app.framerstatic.com/chunk-BQNQQCEJ.mjs";var a=n(t=>{"use strict";var e=i();t.createRoot=e.createRoot,t.hydrateRoot=e.hydrateRoot;var s});export{a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-NZ3T6SXV.mjs.map
