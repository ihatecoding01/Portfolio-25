import{b as r}from"https://app.framerstatic.com/chunk-MOZLLOBH.mjs";r("editorbar");
//# sourceMappingURL=https://app.framerstatic.com/chunk-WHDT6X6O.mjs.map
