import{c as a}from"https://app.framerstatic.com/chunk-BQNQQCEJ.mjs";var d=a((i,e)=>{e.exports=typeof globalThis.React>"u"?void 0:globalThis.React});export{d as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-BBS2LFMO.mjs.map
