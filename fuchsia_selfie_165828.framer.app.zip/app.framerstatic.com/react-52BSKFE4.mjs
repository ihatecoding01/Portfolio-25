import{a}from"https://app.framerstatic.com/chunk-BBS2LFMO.mjs";import"https://app.framerstatic.com/chunk-BQNQQCEJ.mjs";export default a();
//# sourceMappingURL=https://app.framerstatic.com/react-52BSKFE4.mjs.map
