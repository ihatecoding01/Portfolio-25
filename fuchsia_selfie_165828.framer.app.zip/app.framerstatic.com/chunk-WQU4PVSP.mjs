import{k as t}from"https://app.framerstatic.com/chunk-FFXG44IK.mjs";var i;function g(){return i}function u(n){i=n}function E(n){return function(...o){let e=g();e?.enterEventHandling();try{return n(...o)}catch(r){throw e?.errorInEventHandler(t(r)),r}finally{e?.exitEventHandling()}}}export{g as a,u as b,E as c};
//# sourceMappingURL=https://app.framerstatic.com/chunk-WQU4PVSP.mjs.map
