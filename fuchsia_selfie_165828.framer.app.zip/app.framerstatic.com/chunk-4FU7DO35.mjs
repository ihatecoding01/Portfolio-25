import{c as a}from"https://app.framerstatic.com/chunk-BQNQQCEJ.mjs";var d=a((i,e)=>{"use strict";e.exports=typeof globalThis.ReactDOM>"u"?void 0:globalThis.ReactDOM});export{d as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-4FU7DO35.mjs.map
