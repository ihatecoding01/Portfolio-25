import{a as c}from"https://app.framerstatic.com/chunk-BBS2LFMO.mjs";import{c as _}from"https://app.framerstatic.com/chunk-BQNQQCEJ.mjs";var l=_(s=>{"use strict";var y=c(),d=Symbol.for("react.element"),m=Symbol.for("react.fragment"),O=Object.prototype.hasOwnProperty,v=y.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,E={key:!0,ref:!0,__self:!0,__source:!0};function i(t,e,f){var r,o={},n=null,u=null;f!==void 0&&(n=""+f),e.key!==void 0&&(n=""+e.key),e.ref!==void 0&&(u=e.ref);for(r in e)O.call(e,r)&&!E.hasOwnProperty(r)&&(o[r]=e[r]);if(t&&t.defaultProps)for(r in e=t.defaultProps,e)o[r]===void 0&&(o[r]=e[r]);return{$$typeof:d,type:t,key:n,ref:u,props:o,_owner:v.current}}s.Fragment=m;s.jsx=i;s.jsxs=i});var j=_((x,p)=>{"use strict";p.exports=l()});export{j as a};
/*! Bundled license information:

react/cjs/react-jsx-runtime.production.min.js:
  (**
   * @license React
   * react-jsx-runtime.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
//# sourceMappingURL=https://app.framerstatic.com/chunk-HLURFURU.mjs.map
